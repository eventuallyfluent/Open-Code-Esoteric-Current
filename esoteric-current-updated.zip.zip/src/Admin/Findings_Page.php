<?php
namespace EsotericCurrent\Core\Admin;

class Findings_Page {
    public static function render(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $repo = new \EsotericCurrent\Core\Repository\Finding_Repository();
        $finding_repo = $repo;

        if (!empty($_POST['ec_finding_action']) && !empty($_POST['ec_finding_id'])) {
            check_admin_referer('ec_finding_action_' . $_POST['ec_finding_id']);
            $id = (int)$_POST['ec_finding_id'];
            $action = $_POST['ec_finding_action'];
            if ($action === 'publish') {
                self::add_to_editorial_queue($id);
                $finding_repo->update_status($id, 'approved');
                echo '<div class="notice notice-success"><p>Finding published to feed.</p></div>';
            } else {
                $new_status = $action === 'approve' ? 'approved' : 'rejected';
                $finding_repo->update_status($id, $new_status);
                if ($new_status === 'approved') {
                    self::add_to_editorial_queue($id);
                }
                echo '<div class="notice notice-success"><p>Finding ' . esc_html($new_status) . '.</p></div>';
            }
        }

        if (!empty($_POST['ec_bulk_action']) && !empty($_POST['ec_finding_ids'])) {
            check_admin_referer('ec_bulk_findings');
            $ids = array_map('intval', $_POST['ec_finding_ids']);
            $new_status = $_POST['ec_bulk_action'] === 'approve' ? 'approved' : 'rejected';
            $count = 0;
            foreach ($ids as $id) {
                $finding_repo->update_status($id, $new_status);
                if ($new_status === 'approved') {
                    self::add_to_editorial_queue($id);
                }
                $count++;
            }
            echo '<div class="notice notice-success"><p>' . $count . ' findings ' . esc_html($new_status) . '.</p></div>';
        }

        $status = $_GET['status'] ?? 'awaiting_review';
        $findings = $finding_repo->get_all(['status' => $status, 'limit' => 100]);
        $published_ids = self::published_finding_ids();
        ?>
        <div class="wrap">
            <h1>Findings</h1>
            <form method="get">
                <input type="hidden" name="page" value="ec-findings" />
                <select name="status">
                    <option value="awaiting_review" <?php selected($status, 'awaiting_review'); ?>>Awaiting Review</option>
                    <option value="approved" <?php selected($status, 'approved'); ?>>Approved</option>
                    <option value="rejected" <?php selected($status, 'rejected'); ?>>Rejected</option>
                </select>
                <?php submit_button('Filter', 'secondary', '', false); ?>
            </form>
            <form method="post">
                <?php wp_nonce_field('ec_bulk_findings'); ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead><tr><th class="check-column"><input type="checkbox" onclick="document.querySelectorAll('.ec-finding-cb').forEach(c=>c.checked=this.checked)"></th><th>Title</th><th>Type</th><th>Relevance</th><th>Status</th><th>Actions</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php foreach ($findings as $f): ?>
                        <tr>
                            <th class="check-column"><input type="checkbox" class="ec-finding-cb" name="ec_finding_ids[]" value="<?php echo (int)$f['id']; ?>"></th>
                            <td><a href="<?php echo esc_url($f['url']); ?>" target="_blank"><?php echo esc_html(mb_substr($f['title'], 0, 80)); ?></a></td>
                            <td><?php echo esc_html($f['finding_type']); ?></td>
                            <td><?php echo esc_html($f['relevance_score'] ?? 'N/A'); ?></td>
                            <td><?php echo esc_html($f['status']); ?></td>
                            <td>
                            <?php if ($f['status'] === 'awaiting_review'): ?>
                                <form method="post" style="display:inline">
                                    <?php wp_nonce_field('ec_finding_action_' . $f['id']); ?>
                                    <input type="hidden" name="ec_finding_id" value="<?php echo (int)$f['id']; ?>">
                                    <button type="submit" name="ec_finding_action" value="approve" class="button button-small" style="background:#46b450;color:#fff;border-color:#46b450">Approve</button>
                                    <button type="submit" name="ec_finding_action" value="reject" class="button button-small" style="color:#a00">Reject</button>
                                </form>
                            <?php elseif ($f['status'] === 'approved' && !in_array((int)$f['id'], $published_ids, true)): ?>
                                <form method="post" style="display:inline">
                                    <?php wp_nonce_field('ec_finding_action_' . $f['id']); ?>
                                    <input type="hidden" name="ec_finding_id" value="<?php echo (int)$f['id']; ?>">
                                    <button type="submit" name="ec_finding_action" value="publish" class="button button-small" style="background:#2271b1;color:#fff;border-color:#2271b1">Publish to Feed</button>
                                </form>
                            <?php else: ?>
                                &mdash;
                            <?php endif; ?>
                            </td>
                            <td><?php echo esc_html($f['created_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <p>
                    <button type="submit" name="ec_bulk_action" value="approve" class="button" style="background:#46b450;color:#fff;border-color:#46b450">Approve Selected</button>
                    <button type="submit" name="ec_bulk_action" value="reject" class="button" style="color:#a00">Reject Selected</button>
                </p>
            </form>
        </div>
        <?php
    }

    private static function published_finding_ids(): array {
        global $wpdb;
        return array_map('intval', $wpdb->get_col(
            "SELECT source_id FROM {$wpdb->prefix}ec_editorial_queue WHERE source_type = 'finding'"
        ));
    }

    private static function add_to_editorial_queue(int $finding_id): void {
        global $wpdb;
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ec_editorial_queue WHERE source_type = 'finding' AND source_id = %d",
            $finding_id
        ));
        if ($existing) {
            return;
        }
        $finding = (new \EsotericCurrent\Core\Repository\Finding_Repository())->get_by_id($finding_id);
        $wpdb->insert($wpdb->prefix . 'ec_editorial_queue', [
            'source_type' => 'finding',
            'source_id' => $finding_id,
            'workflow_state' => 'published',
            'topic_id' => $finding['topic_id'] ?? null,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ]);
    }
}
